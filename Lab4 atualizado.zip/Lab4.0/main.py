from Repl import *

def prompt():
  Repl().cmdloop()
def test(w):
  Repl().analisador(w)

if __name__ == "__main__":
  prompt()
